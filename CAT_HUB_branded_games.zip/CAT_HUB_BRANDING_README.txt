CAT HUB Branded Script Archive

Brand credit: CAT HUB | catjack.gg
Logo asset: rbxassetid://131425307214118
Background asset reference: rbxassetid://92251347397245

A small logo/credit overlay was added to each Lua file. It attempts to parent the overlay to the executor UI (when available), then CoreGui, then PlayerGui. Compatibility varies by execution environment and by each script's own UI behavior.

The background asset ID is recorded as a reference but is not applied as a full-screen background, because doing so would obscure gameplay and other script interfaces.
