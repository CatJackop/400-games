-- CAT HUB branding: script by catjack.gg
-- Logo asset: rbxassetid://131425307214118
-- Background asset reference: rbxassetid://92251347397245
pcall(function()
    local parent
    pcall(function()
        if typeof(gethui) == "function" then
            parent = gethui()
        end
    end)
    if not parent then
        pcall(function()
            parent = game:GetService("CoreGui")
        end)
    end
    if not parent then
        local player = game:GetService("Players").LocalPlayer
        if player then
            parent = player:WaitForChild("PlayerGui", 5)
        end
    end
    if parent then
        local guiName = "CATHUB_Branding_Logo"
        local oldGui = parent:FindFirstChild(guiName)
        if oldGui then
            oldGui:Destroy()
        end

        local gui = Instance.new("ScreenGui")
        gui.Name = guiName
        gui.ResetOnSpawn = false
        gui.IgnoreGuiInset = true
        gui.DisplayOrder = 999999
        gui.Parent = parent

        local logo = Instance.new("ImageLabel")
        logo.Name = "CAT_HUB_Logo"
        logo.BackgroundTransparency = 1
        logo.Size = UDim2.fromOffset(58, 58)
        logo.Position = UDim2.new(1, -70, 0, 12)
        logo.Image = "rbxassetid://131425307214118"
        logo.ScaleType = Enum.ScaleType.Fit
        logo.Parent = gui

        local label = Instance.new("TextLabel")
        label.Name = "CAT_HUB_Credit"
        label.BackgroundTransparency = 1
        label.Size = UDim2.fromOffset(130, 18)
        label.Position = UDim2.new(1, -142, 0, 72)
        label.Font = Enum.Font.GothamSemibold
        label.Text = "CAT HUB | catjack.gg"
        label.TextSize = 11
        label.TextColor3 = Color3.fromRGB(255, 255, 255)
        label.TextStrokeTransparency = 0.45
        label.TextXAlignment = Enum.TextXAlignment.Right
        label.Parent = gui
    end
end)

-- Ouroboros Hub :: Steal an Egg support notice
local Players = game:GetService("Players")

Players.LocalPlayer:Kick(table.concat({
    "Steal an Egg: No Longer Updated/Supported.",
    "\240\159\135\181\240\159\135\173 Hindi na updated/suportado.",
    "\240\159\135\187\240\159\135\179 Kh\195\180ng c\195\178n c\225\186\173p nh\225\186\173t/h\225\187\151 tr\225\187\163.",
    "\240\159\135\174\240\159\135\169 Tidak diperbarui/didukung.",
    "\240\159\135\183\240\159\135\186 \208\145\208\190\208\187\209\140\209\136\208\181 \208\189\208\181 \208\190\208\177\208\189\208\190\208\178\208\187\209\143\208\181\209\130\209\129\209\143/\208\191\208\190\208\180\208\180\208\181\209\128\208\182\208\184\208\178\208\176\208\181\209\130\209\129\209\143.",
    "\240\159\135\169\240\159\135\170 Nicht mehr aktualisiert/unterst\195\188tzt.",
    "\240\159\135\185\240\159\135\173 \224\185\132\224\184\161\224\185\136\224\184\173\224\184\177\224\184\155\224\185\128\224\184\148\224\184\149/\224\184\163\224\184\173\224\184\135\224\184\163\224\184\177\224\184\154\224\185\129\224\184\165\224\185\137\224\184\167",
}, "\n"))
